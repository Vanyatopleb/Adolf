#!/system/bin/sh
# FiolMenu injector script
# Usage: sh inject.sh [process_name]
# Requires: root (su), libfiol.so in /data/local/tmp/

TARGET="${1:-com.axlebolt.standoff2.huawei}"
SRC_SO="/data/local/tmp/libfiol.so"
INJECTOR="/data/local/tmp/injector"
APP_DATA="/data/data/$TARGET"

echo "========================================="
echo "  FiolMenu Injector"
echo "========================================="
echo "[*] Target: $TARGET"

if [ ! -f "$SRC_SO" ]; then
    echo "[-] $SRC_SO not found!"
    echo "    Push it first: adb push libfiol.so /data/local/tmp/"
    exit 1
fi

if [ ! -f "$INJECTOR" ]; then
    echo "[-] $INJECTOR not found!"
    echo "    Push it first: adb push injector /data/local/tmp/"
    exit 1
fi

chmod 755 "$INJECTOR" 2>/dev/null

# The game runs as an app uid/SELinux domain and usually cannot read
# /data/local/tmp — copy the .so into its own data dir instead.
SO_PATH="$SRC_SO"
if [ -d "$APP_DATA" ]; then
    cp "$SRC_SO" "$APP_DATA/libfiol.so" 2>/dev/null
    APP_UID=$(stat -c %u "$APP_DATA" 2>/dev/null)
    APP_CTX=$(stat -c %C "$APP_DATA" 2>/dev/null)
    if [ -n "$APP_UID" ]; then
        chown "$APP_UID:$APP_UID" "$APP_DATA/libfiol.so" 2>/dev/null
    fi
    if [ -n "$APP_CTX" ]; then
        chcon "$APP_CTX" "$APP_DATA/libfiol.so" 2>/dev/null
    fi
    chmod 644 "$APP_DATA/libfiol.so" 2>/dev/null
    if [ -f "$APP_DATA/libfiol.so" ]; then
        SO_PATH="$APP_DATA/libfiol.so"
    fi
fi
echo "[*] SO: $SO_PATH"

echo "[*] Checking if game is running..."
PID=$(pidof "$TARGET" 2>/dev/null)
if [ -z "$PID" ]; then
    echo "[-] Game process not found!"
    echo "    Start the game first, then run this script."
    exit 1
fi
echo "[+] Game PID: $PID"

echo ""
echo "[*] Injecting..."
su -c "$INJECTOR $TARGET $SO_PATH"

if [ $? -eq 0 ]; then
    echo ""
    echo "[+] Done! Tap the W icon (top-right) to open the menu."
else
    echo ""
    echo "[-] Injection failed. Check logcat:"
    echo "    adb logcat -d | findstr Fiol"
fi
